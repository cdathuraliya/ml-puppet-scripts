#!/bin/bash

echo "Starting performance tests..."
# TODO: Disable carbon metrics
# run server warm-up samples
./warmup.sh
# TODO: Enable carbon metrics
# running tuned samples
./perf-test-tuned.sh
echo "Performance tests completed"